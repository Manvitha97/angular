import { Component, OnInit } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  service:MyserviceService;
  constructor(service:MyserviceService) { 
    this.service=service;
  }
  Employees:Employee[]=[];
  delete(id:string)
  {
    this.service.delete(id);
    this.Employees=this.service.getEmployees();
  }
  
  // isUpdate:boolean=true;
  // updateData()
  // {
  //   this.isUpdate=!this.isUpdate;
  // }
  // update(data:any)
  // {
  //   this.service.update(data);
  //   this.Employees=this.service.getEmployees();
  // }
  
  column:string="id"; 
  order:boolean=true;

  sort(column:string)
  {    
    if(this.column==column )
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  ngOnInit() {
    this.service.fetchEmployees();
    this.Employees=this.service.getEmployees();
  }

  
}

 