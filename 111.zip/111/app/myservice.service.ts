import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http:HttpClient;
  Employees:Employee[]=[];


  constructor(http:HttpClient) {
    this.http=http;
    this.fetchEmployees();
   }
   fetched:boolean=false;
   fetchEmployees()
  {
    this.http.get('./assets/Employees.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );

}
getEmployees():Employee[]
  {
    return this.Employees;
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Employee(o.id,o.name,o.email,o.phone);
      this.Employees.push(e);
    }
  }
  delete(id:string)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.Employees.length;i++)
    {
      let e=this.Employees[i];
      if(id==e.id)
      {
        foundIndex=i;
        break;
      }
    }
    this.Employees.splice(foundIndex,1);
  }
  add(e:Employee){
    this.Employees.push(e);
    
  
}
update(data:any)
  {
    let id=data.id;
    for(let i=0;i<this.Employees.length;i++)
    {
      if(id === this.Employees[i].id)
      {
        this.Employees[i].email=data.email;
        this.Employees[i].phone=data.phone;
        break;
      }
    }
  }
}
export class Employee{
  id:string;
  name:string;
  email:string;
  phone:string;
    constructor(id:string,name:string,email:string,phone:string)
    {
      this.id=id;
      this.name=name;
      this.email=email;
      this.phone=phone;
      
    }
}
